import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // For Stripe webhook requests, we need to return the raw body
  // so we can verify the signature
  if (request.nextUrl.pathname === "/api/webhook") {
    return NextResponse.next({
      request: {
        headers: request.headers,
      },
    })
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/api/webhook"],
}

