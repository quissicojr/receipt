export default function Home() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Stripe Webhook Handler</h1>
      <p>This service processes Stripe webhook events and sends order confirmations and receipts.</p>
    </div>
  )
}

