import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"
import nodemailer from "nodemailer"
import PDFDocument from "pdfkit"
import { Buffer } from "buffer"

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

// Email configuration for GoDaddy (secureserver.net)
const transporter = nodemailer.createTransport({
  host: "smtpout.secureserver.net", // GoDaddy's outgoing SMTP server
  port: 465,
  secure: true, // Use SSL
  auth: {
    user: "support@gadgetxafrica.store", // Your email address
    pass: process.env.EMAIL_PASSWORD || "", // Use environment variable, not hardcoded password
  },
})

// Simple in-memory cache for processed events (in production, use a database or Redis)
const processedEvents = new Set<string>()

// Function to generate HTML confirmation email
function getHtmlConfirmation(session: Stripe.Checkout.Session) {
  const customerName = session.customer_details?.name || "Customer"
  const customerEmail = session.customer_details?.email || ""
  const customerPhone = session.customer_details?.phone || ""
  const transactionId = session.payment_intent as string

  // Get line items data
  const lineItems = session.line_items?.data || []
  const productName = lineItems.length > 0 ? lineItems[0].description || "Product" : "Product"

  const amountPaid = (session.amount_total || 0) / 100
  const orderDate = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Get shipping details
  const shippingDetails = session.shipping_details || {}
  const shippingAddress = shippingDetails.address || {}

  // Get billing details from payment intent
  const billingDetails = { address: {} } as any

  // Simplified HTML template
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>Order Confirmation</title>
  </head>
  <body>
    <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
      <h1>Thank you for your order.</h1>
      <p>We'll let you know when your items are on their way.</p>
      
      <div>
        <strong>Order Number:</strong> ${transactionId}<br>
        <strong>Ordered on:</strong> ${orderDate}
      </div>
      
      <hr>
      
      <h2>Items to be Shipped</h2>
      <div>
        <strong>${productName}</strong><br>
        $${amountPaid.toFixed(2)}
      </div>
      
      <hr>
      
      <h2>Shipping Address:</h2>
      <div>
        ${shippingDetails.name || customerName}<br>
        ${shippingAddress.line1 || ""}<br>
        ${shippingAddress.line2 ? shippingAddress.line2 + "<br>" : ""}
        ${shippingAddress.city || ""}<br>
        ${shippingAddress.state || ""} ${shippingAddress.postal_code || ""}<br>
        ${shippingAddress.country || ""}
      </div>
      
      <hr>
      
      <h2>Payment Details</h2>
      <div>
        <strong>Total:</strong> $${amountPaid.toFixed(2)}
      </div>
      
      <hr>
      
      <footer style="margin-top: 20px; font-size: 12px; color: #666;">
        <p>Copyright © ${new Date().getFullYear()} GadgetX Africa. All rights reserved.</p>
      </footer>
    </div>
  </body>
  </html>
`
}

// Function to generate PDF receipt
async function generateReceiptPdf(session: Stripe.Checkout.Session): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const customerName = session.customer_details?.name || "Customer"
      const transactionId = session.payment_intent as string
      const lineItems = session.line_items?.data || []
      const productName = lineItems.length > 0 ? lineItems[0].description || "Product" : "Product"
      const amountPaid = (session.amount_total || 0) / 100
      const invoiceDate = new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "numeric",
        day: "numeric",
      })

      // Create PDF document
      const doc = new PDFDocument({ margin: 50 })
      const buffers: Buffer[] = []

      doc.on("data", buffers.push.bind(buffers))
      doc.on("end", () => {
        const pdfData = Buffer.concat(buffers)
        resolve(pdfData)
      })

      // Add content to PDF
      doc.fontSize(20).text("Receipt", { align: "center" })
      doc.moveDown()

      doc.fontSize(12).text(`Invoice Number: INV-${Math.floor(Math.random() * 1000000)}`)
      doc.text(`Transaction ID: ${transactionId}`)
      doc.text(`Date: ${invoiceDate}`)
      doc.moveDown()

      doc.text(`Customer: ${customerName}`)
      doc.moveDown()

      // Add table header
      doc.fontSize(10)
      doc.text("Item", 50, doc.y, { width: 250 })
      doc.text("Quantity", 300, doc.y, { width: 50 })
      doc.text("Price", 350, doc.y, { width: 100, align: "right" })
      doc.moveDown()

      // Add line
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke()
      doc.moveDown()

      // Add items
      lineItems.forEach((item) => {
        const quantity = item.quantity || 1
        const price = (item.amount_total || 0) / 100

        doc.text(item.description || "Product", 50, doc.y, { width: 250 })
        doc.text(quantity.toString(), 300, doc.y, { width: 50 })
        doc.text(`$${price.toFixed(2)}`, 350, doc.y, { width: 100, align: "right" })
        doc.moveDown()
      })

      // Add line
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke()
      doc.moveDown()

      // Add total
      doc.text("Total:", 300, doc.y)
      doc.text(`$${amountPaid.toFixed(2)}`, 350, doc.y, { width: 100, align: "right" })

      // Add footer
      doc.fontSize(10).text("Thank you for your business!", 50, 500, { align: "center" })

      doc.end()
    } catch (error) {
      reject(error)
    }
  })
}

// Function to send email with PDF attachment with retry logic
async function sendReceiptEmail(session: Stripe.Checkout.Session, pdfBuffer: Buffer) {
  const customerEmail = session.customer_details?.email
  const customerName = session.customer_details?.name || "Customer"
  const transactionId = session.payment_intent as string

  if (!customerEmail) {
    throw new Error("Customer email not found")
  }

  const mailOptions = {
    from: "support@gadgetxafrica.store",
    to: customerEmail,
    subject: `Your Receipt #${transactionId}`,
    text: `
    Dear ${customerName},

    Thank you for your purchase! Attached is your receipt for the transaction.

    If you have any questions, feel free to contact us.

    Best regards,
    GadgetX Africa
  `,
    attachments: [
      {
        filename: `receipt_${transactionId}.pdf`,
        content: pdfBuffer,
        contentType: "application/pdf",
      },
    ],
  }

  // Implement retry logic
  let retries = 3
  while (retries > 0) {
    try {
      await transporter.sendMail(mailOptions)
      console.log(`✅ Receipt email sent successfully to ${customerEmail}`)
      return
    } catch (error) {
      retries--
      console.error(`❌ Failed to send receipt email (${3 - retries}/3 attempts): ${error}`)
      if (retries === 0) throw error
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Wait 1 second before retry
    }
  }
}

// Function to send HTML confirmation email with retry logic
async function sendConfirmationEmail(session: Stripe.Checkout.Session) {
  const customerEmail = session.customer_details?.email

  if (!customerEmail) {
    throw new Error("Customer email not found")
  }

  const mailOptions = {
    from: "support@gadgetxafrica.store",
    to: customerEmail,
    subject: `We're processing your order #${session.payment_intent}`,
    html: getHtmlConfirmation(session),
  }

  // Implement retry logic
  let retries = 3
  while (retries > 0) {
    try {
      await transporter.sendMail(mailOptions)
      console.log(`✅ Confirmation email sent successfully to ${customerEmail}`)
      return
    } catch (error) {
      retries--
      console.error(`❌ Failed to send confirmation email (${3 - retries}/3 attempts): ${error}`)
      if (retries === 0) throw error
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Wait 1 second before retry
    }
  }
}

// Main webhook handler
export async function POST(request: NextRequest) {
  try {
    // Get the raw request body for signature verification
    const rawBody = await request.text()
    let body
    try {
      body = JSON.parse(rawBody)
    } catch (error) {
      console.error("❌ Error parsing webhook body:", error)
      return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
    }

    // Get the signature from headers
    const signature = request.headers.get("stripe-signature") || ""

    // Verify the webhook signature
    let event: Stripe.Event
    try {
      event = stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET || "")
    } catch (err: any) {
      console.error(`⚠️ Webhook signature verification failed: ${err.message}`)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    // Log the event
    console.log(`Received webhook event: ${event.type} (${event.id})`)

    // Check for idempotency - don't process the same event twice
    if (processedEvents.has(event.id)) {
      console.log(`⚠️ Event ${event.id} already processed, skipping`)
      return NextResponse.json({ received: true, status: "already_processed" })
    }

    // Handle the checkout.session.completed event
    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session

      // Retrieve full session details with expanded objects
      try {
        const fullSession = await stripe.checkout.sessions.retrieve(session.id, {
          expand: ["line_items", "payment_intent", "shipping_cost"],
        })

        if (fullSession.payment_status === "paid") {
          try {
            // Send HTML confirmation email
            await sendConfirmationEmail(fullSession)

            // Generate and send receipt PDF
            const pdfBuffer = await generateReceiptPdf(fullSession)
            await sendReceiptEmail(fullSession, pdfBuffer)

            // Mark event as processed
            processedEvents.add(event.id)

            console.log(`✅ Successfully processed order: ${fullSession.payment_intent}`)
          } catch (error) {
            console.error("❌ Error processing notifications:", error)
          }
        } else {
          console.log(`⚠️ Checkout session ${session.id} is not paid: ${session.payment_status}`)
        }
      } catch (error) {
        console.error("❌ Error retrieving session details:", error)
        // Continue with basic session data
        console.log("⚠️ Proceeding with limited session data")
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("❌ Webhook Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

