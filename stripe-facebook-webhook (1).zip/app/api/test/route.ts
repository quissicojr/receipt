import { NextResponse } from "next/server"

// Simple test endpoint to verify API routes are working
export async function GET() {
  return NextResponse.json({ status: "ok", message: "API is working" })
}

